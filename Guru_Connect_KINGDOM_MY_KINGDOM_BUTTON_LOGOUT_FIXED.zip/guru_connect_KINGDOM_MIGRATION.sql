-- GURU CONNECT KINGDOM / LEARNING REQUEST / CONNECTION / COIN ACCOUNTABILITY PATCH
-- Run once in Supabase SQL Editor. Additive: does not remove existing tables or coin RPCs.

create extension if not exists pgcrypto;

alter table if exists public.gc_learning_requests_v2
  add column if not exists learning_deadline timestamptz,
  add column if not exists learning_scheduled_at timestamptz,
  add column if not exists student_outcome text,
  add column if not exists completed_at timestamptz,
  add column if not exists admin_decision_at timestamptz,
  add column if not exists admin_decision_note text,
  add column if not exists request_code text,
  add column if not exists student_short_id text,
  add column if not exists tutor_short_id text;

-- Stable, human-readable Learning Request ID. Existing IDs are never changed.
create or replace function public.gc_make_learning_request_code()
returns trigger language plpgsql as $$
begin
  if new.request_code is null or btrim(new.request_code)='' then
    new.request_code := 'LR-' || to_char(coalesce(new.created_at,now()),'YYYYMMDD') || '-' || upper(substr(replace(new.id::text,'-',''),1,8));
  end if;
  return new;
end; $$;

drop trigger if exists gc_learning_request_code_trg on public.gc_learning_requests_v2;
create trigger gc_learning_request_code_trg
before insert on public.gc_learning_requests_v2
for each row execute function public.gc_make_learning_request_code();

update public.gc_learning_requests_v2
set request_code='LR-' || to_char(coalesce(created_at,now()),'YYYYMMDD') || '-' || upper(substr(replace(id::text,'-',''),1,8))
where request_code is null or btrim(request_code)='';

create unique index if not exists gc_learning_request_code_uidx on public.gc_learning_requests_v2(request_code);

-- Short IDs for UI. Full UUIDs remain the database keys.
update public.gc_learning_requests_v2 r
set student_short_id=coalesce(student_short_id,'ST-'||upper(substr(replace(student_id::text,'-',''),1,6)))
where student_id is not null;
update public.gc_learning_requests_v2 r
set tutor_short_id=case when tutor_id is null then null else 'TU-'||upper(substr(replace(tutor_id::text,'-',''),1,6)) end;

-- Immutable request records: no client delete policy is created.
-- The connection table is created below, so its REVOKE is intentionally placed after creation.
-- Use guarded DO blocks so this patch does not fail if an older installation does not yet
-- have the coin ledger table.
DO $$
BEGIN
  IF to_regclass('public.gc_learning_requests_v2') IS NOT NULL THEN
    REVOKE DELETE ON public.gc_learning_requests_v2 FROM authenticated;
  END IF;
  IF to_regclass('public.gc_coin_ledger') IS NOT NULL THEN
    REVOKE DELETE ON public.gc_coin_ledger FROM authenticated;
  END IF;
END $$;


-- Public Learning Request board: everyone may READ request cards, but only authenticated
-- registered Tutors can send a connection request through the secure RPC.
alter table if exists public.gc_learning_requests_v2 enable row level security;
drop policy if exists gc_learning_requests_public_read on public.gc_learning_requests_v2;
create policy gc_learning_requests_public_read on public.gc_learning_requests_v2
for select to anon, authenticated using (true);

-- Connection requests table (safe if it already exists).
create table if not exists public.gc_connection_requests (
  id uuid primary key default gen_random_uuid(),
  sender_profile_id uuid not null,
  sender_role text not null check (sender_role in ('student','tutor')),
  recipient_profile_id uuid not null,
  recipient_role text not null check (recipient_role in ('student','tutor')),
  learning_request_id uuid null references public.gc_learning_requests_v2(id) on delete cascade,
  message text,
  status text not null default 'PENDING' check (status in ('PENDING','ACCEPTED','REJECTED')),
  created_at timestamptz not null default now(),
  responded_at timestamptz,
  constraint gc_connection_no_self check(sender_profile_id<>recipient_profile_id)
);

REVOKE DELETE ON public.gc_connection_requests FROM authenticated;

create index if not exists gc_connection_recipient_idx on public.gc_connection_requests(recipient_profile_id,status,created_at desc);
create index if not exists gc_connection_sender_idx on public.gc_connection_requests(sender_profile_id,status,created_at desc);
create index if not exists gc_connection_lr_idx on public.gc_connection_requests(learning_request_id,status);

alter table public.gc_connection_requests enable row level security;

drop policy if exists gc_connection_select_own on public.gc_connection_requests;
create policy gc_connection_select_own on public.gc_connection_requests for select to authenticated using (
 sender_profile_id in(select id from public.student_profiles where user_id=auth.uid()) or
 sender_profile_id in(select id from public.tutor_profiles where user_id=auth.uid()) or
 recipient_profile_id in(select id from public.student_profiles where user_id=auth.uid()) or
 recipient_profile_id in(select id from public.tutor_profiles where user_id=auth.uid())
);

drop function if exists public.gc_send_connection_request(uuid,text,uuid,text);
create or replace function public.gc_send_connection_request(p_target_profile_id uuid,p_target_role text,p_learning_request_id uuid default null,p_message text default null)
returns public.gc_connection_requests language plpgsql security definer set search_path=public as $$
declare sender_id uuid; sender_role text; r public.gc_connection_requests;
begin
 if p_target_role not in('student','tutor') then raise exception 'Invalid target role'; end if;
 select id into sender_id from student_profiles where user_id=auth.uid() limit 1;
 if sender_id is not null then sender_role:='student'; else select id into sender_id from tutor_profiles where user_id=auth.uid() limit 1; if sender_id is not null then sender_role:='tutor'; end if; end if;
 if sender_id is null then raise exception 'Registered Student or Tutor login required'; end if;
 if sender_id=p_target_profile_id then raise exception 'You cannot connect to yourself'; end if;
 if p_learning_request_id is not null then
   if sender_role<>'tutor' or p_target_role<>'student' then raise exception 'Learning Request connection must be sent by a Tutor to the Student'; end if;
   if not exists(select 1 from gc_learning_requests_v2 where id=p_learning_request_id and student_id=p_target_profile_id and status='OPEN' and tutor_id is null) then raise exception 'Learning Request is not open or is already connected'; end if;
   if exists(select 1 from gc_connection_requests where learning_request_id=p_learning_request_id and sender_profile_id=sender_id and status='PENDING') then raise exception 'Connection request already sent'; end if;
 else
   if p_target_role=sender_role then raise exception 'Connection requires the opposite role'; end if;
   if exists(select 1 from gc_connection_requests where sender_profile_id=sender_id and recipient_profile_id=p_target_profile_id and status='PENDING') then raise exception 'Connection request already sent'; end if;
 end if;
 insert into gc_connection_requests(sender_profile_id,sender_role,recipient_profile_id,recipient_role,learning_request_id,message)
 values(sender_id,sender_role,p_target_profile_id,p_target_role,p_learning_request_id,left(coalesce(p_message,''),2000)) returning * into r;
 return r;
end; $$;
grant execute on function public.gc_send_connection_request(uuid,text,uuid,text) to authenticated;

drop function if exists public.gc_respond_connection_request(uuid,text);
create or replace function public.gc_respond_connection_request(p_request_id uuid,p_decision text)
returns public.gc_connection_requests language plpgsql security definer set search_path=public as $$
declare me_id uuid; r public.gc_connection_requests; lr public.gc_learning_requests_v2;
begin
 if upper(p_decision) not in('ACCEPT','REJECT') then raise exception 'Decision must be ACCEPT or REJECT'; end if;
 select id into me_id from student_profiles where user_id=auth.uid() limit 1;
 if me_id is null then select id into me_id from tutor_profiles where user_id=auth.uid() limit 1; end if;
 if me_id is null then raise exception 'Registered login required'; end if;
 select * into r from gc_connection_requests where id=p_request_id for update;
 if not found then raise exception 'Connection request not found'; end if;
 if r.recipient_profile_id<>me_id then raise exception 'Only the recipient can accept or reject this request'; end if;
 if r.status<>'PENDING' then raise exception 'This connection request has already been answered'; end if;
 if upper(p_decision)='REJECT' then update gc_connection_requests set status='REJECTED',responded_at=now() where id=p_request_id returning * into r; return r; end if;
 if r.learning_request_id is not null then
   if r.recipient_role<>'student' or r.sender_role<>'tutor' then raise exception 'Invalid Learning Request connection roles'; end if;
   select * into lr from gc_learning_requests_v2 where id=r.learning_request_id for update;
   if not found then raise exception 'Learning Request not found'; end if;
   if lr.student_id<>me_id then raise exception 'You are not the Student for this Learning Request'; end if;
   if lr.tutor_id is not null or lr.status<>'OPEN' then raise exception 'This Learning Request is no longer open'; end if;
   update gc_learning_requests_v2 set tutor_id=r.sender_profile_id,status='TUTOR_ACCEPTED',tutor_short_id='TU-'||upper(substr(replace(r.sender_profile_id::text,'-',''),1,6)) where id=r.learning_request_id;
 end if;
 update gc_connection_requests set status='ACCEPTED',responded_at=now() where id=p_request_id returning * into r;
 return r;
end; $$;
grant execute on function public.gc_respond_connection_request(uuid,text) to authenticated;

-- Deadline and scheduling are participant-controlled only; no direct client UPDATE is granted.
create or replace function public.gc_set_learning_request_deadline(p_request_id uuid,p_deadline timestamptz)
returns public.gc_learning_requests_v2 language plpgsql security definer set search_path=public as $$
declare r public.gc_learning_requests_v2;
begin
 update public.gc_learning_requests_v2 set learning_deadline=p_deadline where id=p_request_id and student_id in(select id from student_profiles where user_id=auth.uid()) and status='OPEN' returning * into r;
 if not found then raise exception 'Learning Request not found or not owned by Student'; end if;
 return r;
end; $$;
grant execute on function public.gc_set_learning_request_deadline(uuid,timestamptz) to authenticated;

create or replace function public.gc_schedule_learning_session(p_request_id uuid,p_scheduled_at timestamptz)
returns public.gc_learning_requests_v2 language plpgsql security definer set search_path=public as $$
declare r public.gc_learning_requests_v2;
begin
 update public.gc_learning_requests_v2 set learning_scheduled_at=p_scheduled_at where id=p_request_id and tutor_id is not null and (student_id in(select id from student_profiles where user_id=auth.uid()) or tutor_id in(select id from tutor_profiles where user_id=auth.uid())) returning * into r;
 if not found then raise exception 'Connected Learning Request not found'; end if;
 return r;
end; $$;
grant execute on function public.gc_schedule_learning_session(uuid,timestamptz) to authenticated;

-- Internal chat table: participants can insert messages; there is no client DELETE grant.
create table if not exists public.gc_messages (
 id text primary key, from_type text default 'user', from_id text not null, from_name text,
 to_type text default 'user', to_id text not null, to_role text, to_name text,
 subject text, body text not null, created_at timestamptz default now(), read boolean default false
);
alter table public.gc_messages enable row level security;
drop policy if exists gc_messages_participants_select on public.gc_messages;
create policy gc_messages_participants_select on public.gc_messages for select to authenticated using (
 from_id=auth.uid()::text or to_id=auth.uid()::text or
 exists(select 1 from student_profiles s where s.user_id=auth.uid() and (s.id::text=from_id or s.id::text=to_id)) or
 exists(select 1 from tutor_profiles t where t.user_id=auth.uid() and (t.id::text=from_id or t.id::text=to_id))
);
drop policy if exists gc_messages_participants_insert on public.gc_messages;
create policy gc_messages_participants_insert on public.gc_messages for insert to authenticated with check (
 from_id=auth.uid()::text or
 exists(select 1 from student_profiles s where s.user_id=auth.uid() and s.id::text=from_id) or
 exists(select 1 from tutor_profiles t where t.user_id=auth.uid() and t.id::text=from_id)
);
revoke delete on public.gc_messages from authenticated;

-- IMPORTANT: keep the existing secure coin lifecycle. The website calls the existing RPCs:
-- gc_post_learning_request -> debit/hold 100 coins;
-- gc_tutor_complete_learning_request -> Tutor completion;
-- gc_student_learning_request_outcome -> Student confirmation;
-- gc_admin_decide_learning_request -> Admin APPROVE/DENY and final release/return.
-- Admin coin adjustments remain through gc_staff_adjust_coins.
