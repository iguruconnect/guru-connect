-- GURU CONNECT secure Student/Tutor Email+Password linking + Learning Request safety
-- Run this in Supabase SQL Editor. Never put a service-role key in index.html.

create or replace function public.gc_link_auth_profile(p_email text, p_role text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  r text := lower(trim(p_role));
  e text := lower(trim(p_email));
  old_profile record;
  prof record;
  target_id uuid;
begin
  if uid is null or uid::text = '00000000-0000-0000-0000-000000000000' then
    raise exception 'Authentication session required';
  end if;
  if r not in ('student','tutor') then raise exception 'Invalid role'; end if;
  if e = '' then raise exception 'Email required'; end if;

  select * into prof from public.profiles where lower(coalesce(email,''))=e and lower(coalesce(role,''))=r limit 1;
  if r='student' then
    select id,user_id,name,email,phone into old_profile from public.student_profiles
      where lower(coalesce(email,''))=e and coalesce(is_illustrative,false)=false limit 1;
  else
    select t.id,t.user_id,t.name,prof.email,prof.phone into old_profile from public.tutor_profiles t
      left join public.profiles prof on prof.id=t.user_id
      where lower(coalesce(prof.email,''))=e and coalesce(t.is_illustrative,false)=false limit 1;
  end if;
  if old_profile.id is null then raise exception 'Registered profile not found'; end if;
  target_id := old_profile.id;

  insert into public.profiles(id,role,full_name,email,phone)
  values(uid,r,old_profile.name,e,old_profile.phone)
  on conflict(id) do update set role=excluded.role,full_name=excluded.full_name,email=excluded.email,phone=excluded.phone;

  if r='student' then
    update public.student_profiles set user_id=uid where id=target_id;
  else
    update public.tutor_profiles set user_id=uid where id=target_id;
  end if;

  return jsonb_build_object('ok',true,'role',r,'profile_id',target_id,'user_id',uid);
end;
$$;

revoke all on function public.gc_link_auth_profile(text,text) from public;
grant execute on function public.gc_link_auth_profile(text,text) to anon, authenticated;

-- IMPORTANT: gc_post_learning_request must enforce the balance on the server.
-- The following wrapper is intentionally NOT created here because the exact existing
-- RPC body/schema must be preserved. Verify that your existing RPC rejects balances < 100
-- and performs the deduction atomically. The browser also performs a pre-check.

-- Recommended invariant for the existing RPC:
--   1) lock/read the student's wallet
--   2) reject when balance < 100
--   3) deduct exactly 100
--   4) insert the request in one transaction
-- This prevents a zero-coin or double-submit client from bypassing the rule.

-- PUBLIC PROFILE COINS DISPLAY: secure read-only balance RPC
create or replace function public.gc_public_profile_coin_balances(p_profile_ids text[])
returns table(profile_id text, balance numeric)
language sql
security definer
set search_path = public
as $$
  with ids as (select unnest(p_profile_ids)::text as id),
  resolved as (
    select i.id, i.id as wallet_id from ids i
    union all
    select i.id, sp.user_id::text from ids i join student_profiles sp on sp.id::text=i.id where sp.user_id is not null
    union all
    select i.id, tp.user_id::text from ids i join tutor_profiles tp on tp.id::text=i.id where tp.user_id is not null
  ),
  ranked as (
    select r.id, w.balance, row_number() over(partition by r.id order by case when r.wallet_id=r.id then 0 else 1 end) rn
    from resolved r join gc_coin_wallets w on w.profile_id::text=r.wallet_id::text
  )
  select i.id, coalesce(x.balance,0)::numeric
  from ids i left join ranked x on x.id=i.id and x.rn=1;
$$;
revoke all on function public.gc_public_profile_coin_balances(text[]) from public;
grant execute on function public.gc_public_profile_coin_balances(text[]) to anon, authenticated;
